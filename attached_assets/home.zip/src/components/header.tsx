import { useState, useEffect } from "react";
import { Button } from "../components/ui/button";
import { Menu, X } from "lucide-react";
import { Link } from "wouter";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 w-full p-4 z-50 transition-colors duration-300 ${
        isScrolled ? "bg-white shadow-md" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <img
              src="https://vinsonedge.com/wp-content/uploads/2025/01/Logo-3.png"
              alt="11Plus Success"
              className="h-16 cursor-pointer"
            />
          </Link>

          {/* Navigation Links - Hidden on Mobile */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link
              href="/"
              className="text-[#2D3648] hover:text-[#00AA9B] font-medium transition-colors"
            >
              Home
            </Link>
            <Link
              href="/mockexam"
              className="text-[#2D3648] hover:text-[#00AA9B] font-medium transition-colors"
            >
              Mock Exams
            </Link>
            <Link
              href="/holidayclasses"
              className="text-[#2D3648] hover:text-[#00AA9B] font-medium transition-colors"
            >
              Holiay classes
            </Link>
            <Link
              href="/tution"
              className="text-[#2D3648] hover:text-[#00AA9B] font-medium transition-colors"
            >
              Tuition
            </Link>
            <Link
              href="/about"
              className="text-[#2D3648] hover:text-[#00AA9B] font-medium transition-colors"
            >
              About Us
            </Link>
            <Link
              href="/contact"
              className="text-[#2D3648] hover:text-[#00AA9B] font-medium transition-colors"
            >
              Contact Us
            </Link>
          </nav>

          {/* Right side buttons */}
          <div className="flex items-center gap-4">
            <Link className="mt-2" href="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <img
                  src="https://vinsonedge.com/wp-content/uploads/2025/01/Cart.png"
                  alt="Cart"
                  className="h-10 w-10"
                />
                <span className="absolute -top-1 -right-1 bg-[#00AA9B] text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  0
                </span>
              </Button>
            </Link>
            <div className="hidden md:block">
              <Button
                onClick={() => console.log("Redirect to Login")}
                className="bg-[#00AA9B] text-white hover:bg-[#009488] border-none px-6 login-btn"
              >
                Login
              </Button>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6 text-[#2D3648]" />
              ) : (
                <Menu className="h-6 w-6 text-[#2D3648]" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white shadow-lg rounded-b-lg">
            <nav className="flex flex-col space-y-4 py-4">
              <Link
                href="/"
                onClick={() => setIsMenuOpen(false)}
                className="text-[#2D3648] hover:text-[#00AA9B] font-medium px-4"
              >
                Home
              </Link>
              <Link
                href="/mock-exams"
                onClick={() => setIsMenuOpen(false)}
                className="text-[#2D3648] hover:text-[#00AA9B] font-medium px-4"
              >
                Mock Exams
              </Link>
              <Link
                href="/reports"
                onClick={() => setIsMenuOpen(false)}
                className="text-[#2D3648] hover:text-[#00AA9B] font-medium px-4"
              >
                Reports
              </Link>
              <Link
                href="/tution"
                onClick={() => setIsMenuOpen(false)}
                className="text-[#2D3648] hover:text-[#00AA9B] font-medium px-4"
              >
                Tuition
              </Link>
              <Link
                href="/about-us"
                onClick={() => setIsMenuOpen(false)}
                className="text-[#2D3648] hover:text-[#00AA9B] font-medium px-4"
              >
                About Us
              </Link>
              <Link
                href="/contact-us"
                onClick={() => setIsMenuOpen(false)}
                className="text-[#2D3648] hover:text-[#00AA9B] font-medium px-4"
              >
                Contact Us
              </Link>
              <div className="px-4">
                <Button
                  onClick={() => {
                    console.log("Redirect to Login");
                    setIsMenuOpen(false);
                  }}
                  className="w-full bg-[#00AA9B] text-white hover:bg-[#009488] border-none"
                >
                  Login / Sign up
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
